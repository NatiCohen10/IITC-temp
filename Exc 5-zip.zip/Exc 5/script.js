let resultPrint = document.querySelector('.output');
let num1;
let num2;
let usedOperator;

console.log(resultPrint);

function addToScreen(value){
    resultPrint.value += value;
}

function floatingPoint(){
    currentInput = resultPrint.value;
    resultPrint.value = currentInput + '.';
}


function setOperator(operator){
    usedOperator = operator
    num1 = resultPrint.value
    resultPrint.value = ''
    

}

function calculate(){
    num2 = resultPrint.value;
    let number1 = Number(num1)
    let number2 = Number(num2)
    if(usedOperator === '+'){
        const sum = number1 + number2;
        resultPrint.value = sum
        
    }
    else if(usedOperator === '-'){
        const result = number1 - number2;
        resultPrint.value = result
    
    }
    if(usedOperator === '/'){
        const result = number1 / number2;
        resultPrint.value = result
     
    }
    if(usedOperator === '*'){
        const result = number1 * number2;
        resultPrint.value = result
    
    }
    
}

function clearCalc(){
    resultPrint.value = ''
}